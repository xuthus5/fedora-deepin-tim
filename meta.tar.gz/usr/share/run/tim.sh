#!/bin/bash
LD_LIBRARY_PATH=/usr/lib/i386-linux-gnu/deepin-wine WINEPREFIX=$HOME/.deepinwine/Deepin-TIM WINELOADER=/usr/lib/deepin-wine/wine /usr/lib/deepin-wine/wine "c:\\Program Files\\Tencent\\TIM\\Bin\\TIM.exe"
